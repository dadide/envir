# 8.4 new version for the gps test
# taiwan can lib ? where to find
# 

import estimateOutputProcess
from writeUploadRemoveFileClass import UploadRemoveFile, WriteFile
import time
import os
import config
import numpy as np
from ctypes import *
from multiprocessing import Process, Queue

matrix_test_flag = 0

if matrix_test_flag == 0:
    import receiveGPSProcess
    import receiveMatrixProcess
else:
    print('matrix_test_flag == 1')

def receiveMatrixFun(p, queue_matrix):

    if matrix_test_flag == 1:
        
        config.testFun(p, 1, queue_matrix)      # generate data we need to test
    else:
        print('matrix_test_flag == 0')
        count = 1

        logger = config.setUpLogger("receive")

        decode_time = 0.5
       

        while True:
            time_str = config.get_time()
            print('111cantime------' + time_str)
            (mat1, decode_time, spd_flag) = receiveMatrixProcess.receive_can_data(p.step_time, p.freque, p.nPre_channel, decode_time, receiveMatrixProcess.dataptr_can1)            
            # print(mat1)
            # print(spd_flag)
            # spd_flag = 1

            s_time = time.time()

            if spd_flag == 1:
                mat_str = mat1.tobytes()
                queue_matrix.put(mat_str)
                queue_matrix.put(time_str)

                message = 'Received no.%d step data ---- computing!' % count
                print(message)
                logger.info(message)

                count = count + 1

                decode_time = decode_time + time.time() - s_time

      
            else:
                message = 'Received data when low speed or stopping ---- not compute'
                print(message)
                logger.info(message)

                config.generateBlankTxtFile()



def estimateOutputFun(p, queue_matrix, gps_matrix):

    ResultWriter = WriteFile('result/', config.step_num)
    InputWriter = WriteFile('input/', config.step_num)

    [theta_a3d, theta_b3d, mean_in, mean_out] = estimateOutputProcess.loadTheta(p)
    last_r_d = np.zeros([p.r + p.d, p.nAll_channel])
    
    logger = config.setUpLogger("estimate")

    while True:
        try:
            if queue_matrix.empty():
                time.sleep(1)
            else:
                [batch_input, time_str, gps_3c]= estimateOutputProcess.getDataFromQueue(queue_matrix, gps_matrix, p)
                stacked_batch_input = np.vstack((last_r_d, batch_input))

                last_r_d = batch_input[-(p.r + p.d):, :]

                t1 = time.time()
                [phi_a, phi_b, y_batch_true_b, ks, ke] = estimateOutputProcess.constructData(p, mean_in, stacked_batch_input)
                model_index = estimateOutputProcess.chooseModel(phi_b, theta_b3d, y_batch_true_b, ks, ke)
                y_batch_pred_a = estimateOutputProcess.estimateOutput(phi_a, theta_a3d, model_index, mean_out, ks, ke)
                t2 = time.time()

                ResultWriter.save2File(y_batch_pred_a, p, time_str)   

                # ----------------------8.12-----------------------
                # -----cat gps to the last 3 columns to input file-----
                # --- TODO: change the block to a func of receiveGPSProcess.py-----
                try:
                    batch_input_gps =  np.hstack(( batch_input,  gps_3c))     
                    # print(gps_4c.shape, batch_input_gps.shape)                             
                    InputWriter.save2File(batch_input_gps, p, time_str)
                except Exception as e:
                    print(e)
                # -----------------------------------------------

                t3 = time.time()
                message = 'estimate consumes:{:0.2f}, write consumes:{:0.2f}'.format(t2-t1, t3-t2)
                logger.info(message)
                print(message)
        except Exception as e:
            print(e)
            break


def uploadRmFileFun():
    UpRm = UploadRemoveFile(config.AccessKeyId, config.AccessKeySecret, config.endpoint, config.bucketName, config.source_root_fold)
    while True:
        try:
            UpRm.findUploadRemoveFile('input/')
            time.sleep(1)
            UpRm.findUploadRemoveFile('result/')
            time.sleep(1)
            UpRm.findUploadRemoveFile('log/')
            time.sleep(1)
        except:
            break

def receviceGPSFun(p, gps_matrix):
    last_gps = [0, 0, 0, -100]
    while True:
        s_time = time.time()
        curtime = config.get_time()
        print('222gpstime------' + curtime)
        
        if matrix_test_flag == 0:
            # not the test code            
            gps_mat = receiveGPSProcess.receviceGPS(p, last_gps)
            last_gps = gps_mat[-1, :]
            reshape_gps_mat = receiveGPSProcess.reshapeGPS(gps_mat, p, receiveGPSProcess.SampleRate)
            # raw_gps_mat_512 = receiveGPSProcess.addZero512(gps_mat, p, receiveGPSProcess.SampleRate)
            # print(gps_mat.shape, gps_mat)
            rece_time = time.time() - s_time
            # print('rece_time: ' + str(rece_time))
            wait_time = max(0, p.step_time - rece_time)
            # print('wait_time: ' + str(wait_time) + '!!!!!\n\n\n')
            if wait_time != 0:
                time.sleep(wait_time) 
        else:
            # test code
            reshape_gps_mat = config.testGPS(p, last_gps)        

        #--- 8.19---
        # with open('./raw/'+config.get_time()+'.csv', 'w') as f:
        #     np.savetxt(f, gps_mat, fmt='%.8f', delimiter=',')

        # --- 8.18--- only put the later 3 channel into the mat
        # combine_reshape_raw = np.vstack((reshape_gps_mat[:, 1:4], raw_gps_mat_512[:, 1:4]))
        # mat_str = combine_reshape_raw.tobytes()

        mat_str = reshape_gps_mat[:, 1:4].tobytes()
        gps_matrix.put(mat_str)


if __name__ == "__main__":

    # p = config.Param(512, 10, 10, 23, 28, 18, 3, 20, 0, 2, 'MTheta/')  # after changing --- reshape38
    p = config.Param(512, 10, 5, 53, 28, 18, 3, 20, 0, 17, 'MTheta/')  # after changing

    # p = config.Param(512, 10, 10, 9, 70, 6, 3, 50, 0, 'MTheta/')    #canfd1


    # freque, spdfre, step_time, nAll_channel, nOu_a, nIn_b, nOu_b, r, d, nPre_channel, theta_path      

    queue_matrix = Queue()
    gps_matrix = Queue()

    # process1 = Process(target=receiveMatrixFun, kwargs={"p":p, "queue_matrix":queue_matrix})
    # process2 = Process(target=receiveSpeedFun, kwargs={"p":p, "queue_speed":queue_speed})
    process5 = Process(target=receviceGPSFun, kwargs={"p":p, "gps_matrix":gps_matrix})
    process3 = Process(target=estimateOutputFun, kwargs={"p":p, "queue_matrix":queue_matrix, "gps_matrix":gps_matrix})
    # process4 = Process(target=uploadRmFileFun, kwargs={})
    

    # process1.start()
    # process2.start()   
    process3.start()
    # process4.start()
    process5.start()

    try:
        receiveMatrixFun(p, queue_matrix)
        # process1.join()
        # process2.join()
        process3.join()
        # process4.join()
        process5.join()

    except Exception as e:
        # process1.terminate()
        # process1.join()

        # process2.terminate()
        # process2.join()
        print(e)
        process3.terminate()
        process3.join()

        # process4.terminate()
        # process4.join()
        
        process5.terminate()
        process5.join()

        receiveMatrixProcess.p0End_zlg()
        receiveMatrixProcess.p0End_taiwan()
        print("Finished successfully!")
        
