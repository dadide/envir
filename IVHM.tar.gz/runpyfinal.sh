#!/bin/bash


python3 -u testdev.py







