#!/bin/bash


python3 -u test_oss_docker.py







