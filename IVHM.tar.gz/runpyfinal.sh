#!/bin/bash


python3 -u final_upload.py







