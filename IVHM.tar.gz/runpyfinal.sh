#!/bin/bash

#nohup python3 -u main_process.py > log/terminal.log &

#python3 -u main_process.py > log/terminal.log 2>&1

# python3 -u main_process.py
cd /IVHM
python3 -u main_process.py




