import serial  # 引用pySerial模組
import numpy as np

COM_PORT = '/dev/ttyUSB3'                   # 指定通訊埠名稱
BAUD_RATES = 115200    	                    # 設定傳輸速率
ser = serial.Serial(COM_PORT, BAUD_RATES)   # 初始化序列通訊埠
SampleRate = 1 #GPS模块的刷新率

def receviceGPS(p, last_gps):
    cnt = 0
    step_time =5
    print(step_time)
    gps_mat = np.zeros([step_time, 4]) - 1

    try:
        while True:
            while ser.in_waiting:          # 若收到序列資料…
                data_raw = ser.readline()  # 讀取一行
                data = data_raw.decode()   # 用預設的UTF-8解碼
                # print('接收到的原始資料：', data_raw)
                # print('接收到的資料：', data)
                line = data.strip()
                element = line.split(',')
                if element[0] == '$GPRMC':                    
                    if element[2] == 'A':
                        # new = [element[1], element[3], element[5], element[7]]
                        lat = float(element[3][:2]) + float(element[3][2:])/60
                        lon = float(element[5][:3]) + float(element[5][3:])/60
                        gps_data = [[ element[1], lat, lon, element[7]]]
                    elif element[2] == 'V':
                        if cnt != 0:    
                            gps_data = gps_mat[cnt-1, :]
                        else:   
                            gps_data = last_gps

                    print(gps_data)
                    gps_mat[cnt, :] = np.asarray(gps_data)
                    print(cnt)     
                    if cnt >= 4:
                        break
                    else:
                        cnt = cnt + 1
                break
        return gps_mat
    except KeyboardInterrupt:
        ser.close()    
        print('再見！')    

def reshapeGPS(gps_mat, p):
    # TODO: 师兄在这里写下reshape的代码即可
    # 输入gps_mat是一个(5, 4)或者(10, 4)的numpy，输出也为一个(512*5, 4)的numpy

    upper_frequency = p.step_time * p.freque

    gps_time =gps_mat[:,0]
    gps_lat = gps_mat[:,1]
    gps_lon = gps_mat[:,2]
    gps_spd = gps_mat[:,3]

    resample_time_mat = signal.resample_poly(gps_time, upper_frequency, gps_mat.shape[0], padtype='line')
    resample_time_vec = resample_time_mat.reshape(resample_time_mat.shape[0], 1)

    resample_lat_mat = signal.resample_poly(gps_lat, upper_frequency, gps_mat.shape[0], padtype='line')
    resample_lat_vec = resample_lat_mat.reshape(resample_lat_mat.shape[0], 1)

    resample_lon_mat = signal.resample_poly(gps_lon, upper_frequency, gps_mat.shape[0], padtype='line')
    resample_lon_vec = resample_lon_mat.reshape(resample_lon_mat.shape[0], 1)

    resample_spd_mat = signal.resample_poly(gps_spd, upper_frequency, gps_mat.shape[0], padtype='line')
    resample_spd_vec = resample_spd_mat.reshape(resample_spd_mat.shape[0], 1)

    upper_gps_mat = np.hstack((resample_time_vec, resample_lat_vec, resample_lon_vec, resample_spd_vec))

    return upper_gps_mat