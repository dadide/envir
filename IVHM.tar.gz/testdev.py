import serial
import crcmod._crcfunext
import oss2
import time

# port setting
COM_PORT = '/dev/ttyUSB5'                  
BAUD_RATES = 115200                              
ser = serial.Serial(COM_PORT, BAUD_RATES)  


# oss setting
auth = oss2.Auth('LTAI5t5YP36JjczH9A5EMXPp', 'Sm4B7y6BhFk90JtouStGV1LoWWgcJY')
endpoint = 'https://oss-cn-shanghai.aliyuncs.com'
bucket = oss2.Bucket(auth, endpoint, 'whyfailed')        


def get_time():
	# Func : to get the current time
	time_tup = time.localtime(time.time())
	format_time='%Y_%m_%d-%H_%M_%S'
	cur_time = time.strftime(format_time, time_tup)
	return cur_time


for i in range(100):
	# create a txt contains the index number
	cur_time = get_time()

	dest_file_name = 'dir/' + cur_time + '.txt';
	sour_file_name = '/IVHM/' + cur_time + '.txt';	# local file

	while ser.in_waiting:
		data_raw = ser.readline()  
        data = data_raw.decode() 
		with open(sour_file_name, 'w') as f:
			f.write(cur_time)
			f.write(cur_time + '---' + str(data_raw))
			f.write(cur_time + '+++' + str(data))

	bucket.put_object_from_file(dest_file_name, sour_file_name)

	time.sleep(2)

ser.close()