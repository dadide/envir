
import time
import cantools
import numpy as np
from ctypes import *

import crcmod._crcfunext
import oss2

# oss setting
auth = oss2.Auth('LTAI5t5YP36JjczH9A5EMXPp', 'Sm4B7y6BhFk90JtouStGV1LoWWgcJY')
endpoint = 'https://oss-cn-shanghai.aliyuncs.com'
bucket = oss2.Bucket(auth, endpoint, 'whyfailed')        



db = cantools.database.load_file('./CSMconfig1_500Hz_butterworth200Hz.dbc')
#db2 = cantools.database.load_file('./20151030-zx4_AS22_EP_HSC1-V18.dbc')
canDLL = cdll.LoadLibrary('./libcontrolcan.so')
#MyDLL = cdll.LoadLibrary('./Ccode/libtest.so')

VCI_USBCAN2 = 4
STATUS_OK = 1


date = ''

def get_time():
	# Func : to get the current time
	time_tup = time.localtime(time.time())
	format_time='%Y_%m_%d-%H_%M_%S'
	cur_time = time.strftime(format_time, time_tup)
	return cur_time


class DBC_INFO(Structure):
	_fields_ = [("matrix_column_value", c_int),
				("matrix_row", c_int),
				("filled_column", c_int),
				("matrix_row_value", c_int),
				("timestamp",c_int)#int timestamp;
				]

class JumpError(Exception):
	def __init__(self, value):
		self.value = value

	def __str__(self):
		return repr(self.value)


class VCI_INIT_CONFIG(Structure):
	_fields_ = [("AccCode", c_uint),
				("AccMask", c_uint),
				("Reserved", c_uint),
				("Filter", c_ubyte),
				("Timing0", c_ubyte),
				("Timing1", c_ubyte),
				("Mode", c_ubyte)
				]


class VCI_CAN_OBJ(Structure):
	_fields_ = [("ID", c_uint),
				("TimeStamp", c_uint),
				("TimeFlag", c_ubyte),
				("SendType", c_ubyte),
				("RemoteFlag", c_ubyte),
				("ExternFlag", c_ubyte),
				("DataLen", c_ubyte),
				("Data", c_ubyte * 8),
				("Reserved", c_ubyte * 3)
				]


class VCI_FILTER_RECORD(Structure):
	_fields_ = [("ExtFrame", c_uint),
				("Start", c_uint),
				("End", c_uint)
				]
DataMap = {  'D_Ac_X_FM': 16,  'D_Ac_Y_FM': 17,  'M3_A': -1,  'D_Ac_Z_FM': 18,  'D_Ac_X_RM': 19,  'D_Ac_Y_RM': 20,  'D_Ac_Z_RMXXX': -1,  'D_Ac_X_Wl_FL': 0,  'D_Ac_Y_Wl_FL': 1,  'D_Ac_Z_Wl_FL': 2,  'D_Ac_X_Wl_FR': 3,  'D_Ac_Y_Wl_FR': 4,  'D_Ac_Z_Wl_FR': 5,  'D_Ac_X_Wl_RL': 6,  'D_Ac_Y_Wl_RL': 7,  'D_Ac_Z_Wl_RL': 8,  'D_Ac_X_Wl_RR': 9,  'D_Ac_Y_Wl_RR': 10,  'D_Ac_Z_Wl_RR': 11,  'D_Dis_Dmp_FL': 12,  'D_Dis_Dmp_FR': 13,  'D_Dis_Dmp_RL': 14,  'D_Dis_Dmp_RR': 15,  'D_Ac_Z_RM': 21, }

ubyte_array = c_ubyte * 8

ret = canDLL.VCI_OpenDevice(VCI_USBCAN2, 0, 0)

vci_initconfig = VCI_INIT_CONFIG(0x80000008, 0xFFFFFFFF, 0,
								 2, 0x00, 0x1C, 0)  # 波特率125k，正常模式
ret = canDLL.VCI_InitCAN(VCI_USBCAN2, 0, 0, byref(vci_initconfig))
if ret != STATUS_OK:
	print('Failed: VCI_InitCAN1')

vci_filter_record = VCI_FILTER_RECORD(0, 0x500, 0x650)  #滤波器，代表起止帧数，但是没用到
# print(canDLL.VCI_SetReference(21, 0, 0,3,0))
ret = canDLL.VCI_StartCAN(VCI_USBCAN2, 0, 0)
if ret != STATUS_OK:
	print('Failed: VCI_StartCAN1')

ret = canDLL.VCI_InitCAN(VCI_USBCAN2, 0, 1, byref(vci_initconfig))
if ret != STATUS_OK:
	print('Failed: VCI_InitCAN2')

# print(canDLL.VCI_SetReference(21, 0, 0,3,0))
ret = canDLL.VCI_StartCAN(VCI_USBCAN2, 0, 1)
if ret == STATUS_OK:
	print('Can Bus Initialized Successfully')
if ret != STATUS_OK:
	print('Failed: VCI_StartCAN2')

a = ubyte_array(1, 2, 3, 0, 0, 0, 0, 0)
ubyte_3array = c_ubyte * 3
b = ubyte_3array(0, 0, 0)
#vci_can_obj_time = (VCI_CAN_OBJ*100000)() #Buffer
vci_can_obj_data = (VCI_CAN_OBJ*1000000)() #Buffer
dataAdd=0
Addr=0
TimeFlag=1
mat_c = np.zeros([5120, 24])
tmp = np.asarray(mat_c)
dataptr = tmp.ctypes.data_as(POINTER(c_double))

cur_time = get_time()
dest_file_name = 'dir/' + cur_time + '.txt';
sour_file_name = '/IVHM/' + cur_time + '.txt';	# local file
with open(sour_file_name, 'w') as f:
	f.write('start!!!')

while 1:


	ret2 = canDLL.VCI_Receive(VCI_USBCAN2, 0, 1, byref(vci_can_obj_data,Addr*sizeof(VCI_CAN_OBJ)), 2500, 0)
	#print(ret2)
	if ret2:
		ms_data = db.decode_message(vci_can_obj_data[0].ID, vci_can_obj_data[0].Data)
		for k, v in ms_data.items():
			print(k)
			print(v)
			with open(sour_file_name, 'a') as f:
				f.write(str(k))
				f.write(str(v))

	time.sleep(0.1)
	Addr=Addr+ret2
	if Addr>5120*6:
		break
dbc_info = DBC_INFO(22, 0, 0, 5120,0)
print(Addr)

bucket.put_object_from_file(dest_file_name, sour_file_name)


#MyDLL.DBC_Decode(byref(vci_can_obj_data), Addr, dataptr, byref(dbc_info))#
'''
try:
	while 1:
		#ret = canDLL.VCI_Receive(VCI_USBCAN2, 0, 0, byref(vci_can_obj_time), 10, 0)
		ret2 = canDLL.VCI_Receive(VCI_USBCAN2, 0, 1, byref(vci_can_obj_data,dataAdd*sizeof(VCI_CAN_OBJ)), 2500, 0)

		time.sleep(0.01)
		if ret2>0:
			dataAdd=dataAdd+ret2
			print(str(dataAdd)+'_'+str(ret2))
except(KeyboardInterrupt):
		count2=0
		countData=0
		mat = np.zeros([100000, 24])
		info =np.zeros([24],int)
		canDLL.VCI_CloseDevice(VCI_USBCAN2, 0)

		while count2 < dataAdd:
			ms_data = db.decode_message(vci_can_obj_data[count2].ID, vci_can_obj_data[count2].Data)
			for k, v in ms_data.items():
				if DataMap[k] < 0:
					continue
				info[DataMap[k]] = info[DataMap[k]] + 1
				p = info[DataMap[k]]
				print(vci_can_obj_data[count2].TimeStamp)
				mat[info[DataMap[k]] - 1, DataMap[k]] = v
			count2 = count2 + 1

		np.savetxt('MAT.csv', mat[:p, :], delimiter=',')
	#if ret > 0:
	#	count=0
	#	while count < ret:
	#		if(vci_can_obj_time[count].ID==0xc9):
	#			ms_time = db2.decode_message(vci_can_obj_time[count].ID, vci_can_obj_time[count].Data)
	#			date=''
				#for k, v in ms_time.items():
					#print(k)
					#print(v)
	#		count=count+1
	#if ret2 > 0:
	#	count2=0
	#	while count2 < ret2:
	#		if(vci_can_obj_data[count2].ID>0):
	#			ms_data = db.decode_message(vci_can_obj_data[count2].ID, vci_can_obj_data[count2].Data)
	#			date=''
	#			for k, v in ms_data.items():
	#				print(k)
	#				print(v)
	#		count2=count2+1
header = 'For_SSL_FL,For_SSL_FR,For_STR_FL,For_STR_FR,For_BJ_X_FL,For_BJ_Y_FL,For_BJ_X_FR,For_BJ_Y_FR,Ms_LCA_FL1,Ms_LCA_FL2,Ms_LCA_FL3,Ms_LCA_FR1,Ms_LCA_FR2,Ms_LCA_FR3,Ms_FSSL,Ms_RSSL,Ms_TA_RL1,Ms_TA_RL2,Ms_TA_RL3,Ms_TA_RR1,Ms_TA_RR2,Ms_TA_RR3,Ms_UCA_RL,Ms_UCA_RR,Ms_LCA_RL1,Ms_LCA_RL2,Ms_LCA_RR1,Ms_LCA_RR2,For_TL_RL,For_TL_RR,For_SSL_RL,For_SSL_RR,WFT_Fx_FL,WFT_Fy_FL,WFT_Fz_FL,WFT_Mx_FL,WFT_My_FL,WFT_Mz_FL,WFT_Fx_FR,WFT_Fy_FR,WFT_Fz_FR,WFT_Mx_FR,WFT_My_FR,WFT_Mz_FR,WFT_Fx_RL,WFT_Fy_RL,WFT_Fz_RL,WFT_Mx_RL,WFT_My_RL,WFT_Mz_RL,WFT_Fx_RR,WFT_Fy_RR,WFT_Fz_RR,WFT_Mx_RR,WFT_My_RR,WFT_Mz_RR,Acc_X_FLLB,Acc_Y_FLLB,Acc_Z_FLLB,Acc_X_FRLB,,Acc_Y_FRLB,Acc_Z_FRLB,Acc_X_FS,Acc_Y_FS,Acc_Z_FS,Acc_X_RS,Acc_Y_RS,Acc_Z_RS,Acc_X_DSB, Acc_Z_DSB'
'''
