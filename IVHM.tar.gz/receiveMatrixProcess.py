import cantools
import time
import platform
import config
import numpy as np
from ctypes import *
from scipy import signal

#-------------------------------------Load dynamic lib-----------------------------------------

# clib = cdll.LoadLibrary('lib/libfaro_can_sdk.so')	# ban card
canmini_so = cdll.LoadLibrary('./Ccode/Can/libusbcan.so') #  can lib

sensor_decode_so = cdll.LoadLibrary('lib/mveg2110_20210524.so')
# sensor_decode_so = cdll.LoadLibrary('lib/can1.so')

# vehicle_db = cantools.database.load_file('./Ccode/Vehicle_Sensor/canvehicle.Dbc')


#-------------------------------------sensor number-----------------------------------------
dim_canmini=36		# channel number = column of mat
id_num_canmini=12	# sensor number

def p0End():
	canmini_so.VCI_ResetCAN(USBCAN2,DEVICE_INDEX,CHANNEL0)
	canmini_so.VCI_ResetCAN(USBCAN2,DEVICE_INDEX,CHANNEL1)
	canmini_so.VCI_CloseDevice(USBCAN2,DEVICE_INDEX,CHANNEL0)
	canmini_so.VCI_CloseDevice(USBCAN2,DEVICE_INDEX,CHANNEL1)



#--------------------------------Config can device function---------------------------------------------------
# def input_thread():
#	input()

# FOR sensor data receive
class DBC_INFO(Structure):
	_fields_ = [("matrix_column_value", c_int),
				("matrix_row", c_int),
				("frequency", c_int),
				("matrix_row_value", c_int),
				("timestamp",c_int),#int timestamp;
				("calcul_batch",c_int),
				('id_num_can',c_int)
				]


class ZCAN_CAN_INIT_CONFIG(Structure):
	_fields_ = [("AccCode",c_int),
				("AccMask",c_int),
				("Reserved",c_int),
				("Filter",c_ubyte),
				("Timing0",c_ubyte),
				("Timing1",c_ubyte),
				("Mode",c_ubyte)]

class ZCAN_CAN_OBJ(Structure):
	_fields_ = [("ID",c_uint32),
				("TimeStamp",c_uint32),
				("TimeFlag",c_uint8),
				("SendType",c_byte),
				("RemoteFlag",c_byte),
				("ExternFlag",c_byte),
				("DataLen",c_byte),
				("Data",c_ubyte*8),
				("Reserved",c_ubyte*3)]


def can_start(DEVCIE_TYPE,DEVICE_INDEX,CHANNEL,Brate):
	 init_config  = ZCAN_CAN_INIT_CONFIG()
	 init_config.AccCode	= 0
	 init_config.AccMask	= 0xFFFFFFFF
	 init_config.Reserved   = 0
	 init_config.Filter	 = 1
	 init_config.Timing0	= 0x00
	 init_config.Timing1	= Brate
	 init_config.Mode	   = 0
	 # Initialize the  Can channel 
	 Init_flag=canmini_so.VCI_InitCAN(DEVCIE_TYPE,DEVICE_INDEX,CHANNEL,byref(init_config))
	 if Init_flag ==0:
		 print("InitCAN fail!")
	 else:
		 print("InitCAN success!")
	  #Start  Can channel	
	 start_flag=canmini_so.VCI_StartCAN(DEVCIE_TYPE,DEVICE_INDEX,CHANNEL)
	 if start_flag ==0:
		 print("StartCAN fail!")
	 else:
		 print("StartCAN success!")
	 return start_flag


# -------------------------------------------config canfd function---------------------------------------
# remove!

# ----------------------------can device parameter setting--------------------------------------------------- 
ZCAN_DEVICE_TYPE  = c_uint32
ZCAN_DEVICE_INDEX = c_uint32
ZCAN_Reserved	 = c_uint32
ZCAN_CHANNEL	  = c_uint32
LEN			   = c_uint32

USBCAN2	   =   ZCAN_DEVICE_TYPE(4)
DEVICE_INDEX  =   ZCAN_DEVICE_INDEX(0)
Reserved	  =   ZCAN_Reserved(0)

# specify which channel to receive data 0--> channel 0	  1--> channel 1
CHANNEL0	   =   ZCAN_CHANNEL(0) # for receiving acceleration 
CHANNEL1	   =   ZCAN_CHANNEL(1) # for receiving time and speed 

Brate0=0x1C # bode rate for channel 0 
Brate1=0x14 # bode rate for channel 1
# close can if they open unexpectally 
bRel0=canmini_so.VCI_CloseDevice(USBCAN2,DEVICE_INDEX, CHANNEL0) # close can 1
bRel1=canmini_so.VCI_CloseDevice(USBCAN2,DEVICE_INDEX, CHANNEL1)  # close can 2

# open device
open_flag=canmini_so.VCI_OpenDevice(USBCAN2,DEVICE_INDEX,Reserved) # open device 

if open_flag ==0:
 	print("Opendevice fail!")
else:
 		print("Opendevice success!")

# start can 
canstart0 = can_start(USBCAN2,DEVICE_INDEX,CHANNEL0,Brate0) # start can 0
canstart1 = can_start(USBCAN2,DEVICE_INDEX,CHANNEL1,Brate1) # start can 1


# ----------------------------   run canFD device config-------------------------------------------
# remove!

# -------------my function------------------------------
def receive_can_data(calcul_batch, frequ, nPre_channel, decode_time):
	matrix_row_value = frequ * calcul_batch

	s1_time = time.time()
	# ---------------------------------------can 0---------------------------------------
	# EPTAccelActuPosHSC1
	# BrkPdlDrvrAppdPrsHSC1
	# BrkPdlPos_h1HSC1
	# VehSpdAvgDrvnHSC1
	
	spd_list_can0 = []
	brk_list_can0 = []
	obj_can0 = (ZCAN_CAN_OBJ * 100000)()
	spd_mat_can0 = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	brk_mat_can0 = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	

	# # ---------------------------------------can 1---------------------------------------
	obj_can1 = (ZCAN_CAN_OBJ * 100000)() # matrix_row_value)()
	mat_can1 = np.zeros([frequ * calcul_batch, dim_canmini], np.float64) - 1
	tmp_can1 = np.asarray(mat_can1)
	dataptr_can1 = tmp_can1.ctypes.data_as(POINTER(c_double))
	dbc_info_can1 = DBC_INFO(dim_canmini, 0, frequ, matrix_row_value, 0, calcul_batch, id_num_canmini)
# "matrix_column_value", "matrix_row", "frequency", "matrix_row_value", "timestamp","calcul_batch",'id_num_can'

	init_time = time.time() - s1_time
	print('init_time: ' + str(init_time))

	for i in range(0, calcul_batch):
		# ------------------------------------sleep for fixed time--------------------------------------------
		# if i == 9:
		# 	time.sleep(0.985 - decode_time - init_time)
		# else:
		time.sleep(1 - decode_time - init_time)
		init_time = 0
		s2_time = time.time()

		# # ---------------------------------------receive data from can 0---------------------------------------
		# max_num_can0 = canmini_so.VCI_GetReceiveNum(USBCAN2, DEVICE_INDEX, CHANNEL0)  # preview the number of data in cache
		# act_num_can0 = canmini_so.VCI_Receive(USBCAN2, DEVICE_INDEX, CHANNEL0, byref(obj_can0), max_num_can0, 100)
		# print(max_num_can0, act_num_can0)

		# ---------------------------------------receive data from can 1---------------------------------------
		max_num_can1 = canmini_so.VCI_GetReceiveNum(USBCAN2, DEVICE_INDEX, CHANNEL1)  # preview the number of data in cache
		act_num_can1 = canmini_so.VCI_Receive(USBCAN2, DEVICE_INDEX, CHANNEL1, byref(obj_can1), max_num_can1, 100)
		print(max_num_can1, act_num_can1)


		# ////////////////////////////////////////////decode//////////////////////////////////////////////////////
		# --------------------------------------can0 (vehicle sensor)-----------------------------------------------
		
		# spd_temp_list = speedDecode(obj_can0, act_num_can0)
		# spd_list_can0.extend( spd_temp_list )

		# brk_temp_list = brakeDecode(obj_can0, act_num_can0)
		# brk_list_can0.extend( brk_temp_list )		
		
		# -------------------------------------- can1 (IMU, 6 dimentions) -----------------------------------------------------
		if act_num_can1 > 0:
			try:
				t = sensor_decode_so.DBC_Decode(byref(obj_can1), act_num_can1, i, dataptr_can1, byref(dbc_info_can1))
				print(t)
			except Exception as e:
				p0End();

		decode_time = time.time() - s2_time
		print(dbc_info_can1.matrix_row)
		print('decode_time: ' + str(decode_time))

	# --------------------------------------can0 (vehicle sensor)-----------------------------------------------
	# spd_array_can0 = np.asarray(spd_list_can0)
	# brk_array_can0 = np.asarray(brk_list_can0)

	# print(brk_array_can0)
	
	# try:

	# 	spd_array_can0 = signal.resample_poly(spd_array_can0, frequ * calcul_batch, spd_array_can0.shape[0], padtype='line')
	# 	spd_mat_can0 = spd_array_can0.reshape(spd_array_can0.shape[0], 1)

	# 	brk_array_can0 = signal.resample_poly(brk_array_can0, frequ * calcul_batch, brk_array_can0.shape[0], padtype='line')
	# 	brk_mat_can0 = brk_array_can0.reshape(brk_array_can0.shape[0], 1)
	
	# except Exception as e:

	# 	spd_mat_can0 = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	# 	brk_mat_can0 = np.zeros([frequ * calcul_batch, 1], np.float64) + 1

	# ----------------------------------------------------------------------------------------------------------
#header_input_str='Speed,brake,Gyro_Y,Gyro_X,Acc_Y_FM,Gyro_Z,Acc_X_FM,Acc_Z_FM,Acc_Z_Whl_LF,Acc_Y_Whl_LF,Acc_X_Whl_LF,Acc_Z_Whl_RF,Acc_Y_Whl_RF,Acc_X_Whl_RF,Acc_Y_Whl_LR,Acc_X_Whl_LR,Acc_Z_Whl_LR,Acc_Y_Whl_RR,Acc_X_Whl_RR,Acc_Z_Whl_RR,Acc_X_RM,Acc_Y_RM,Acc_Z_RM'

	# combined_matrix = np.hstack((spd_mat_can0, brk_mat_can0, mat_can1))
	
	# combined_matrix[:,1+nPre_channel] = -combined_matrix[:,1+nPre_channel]  # Gyro_X
	# combined_matrix[:,4+nPre_channel] = -combined_matrix[:,4+nPre_channel]  # Acc_X_FM
	# combined_matrix[:,7+nPre_channel] = -combined_matrix[:,7+nPre_channel]  # Acc_Y_Whl_LF
	# combined_matrix[:,9+nPre_channel] = -combined_matrix[:,9+nPre_channel]  # Acc_Z_Whl_RF
	# combined_matrix[:,13+nPre_channel] = -combined_matrix[:,13+nPre_channel]  # Acc_X_Whl_LR
	# combined_matrix[:,16+nPre_channel] = -combined_matrix[:,16+nPre_channel]  # Acc_X_Whl_RR
	# combined_matrix[:,18+nPre_channel] = -combined_matrix[:,18+nPre_channel]  # Acc_X_RM
	# combined_matrix[:,19+nPre_channel] = -combined_matrix[:,19+nPre_channel]  # Acc_Y_RM

	# print(combined_matrix.shape)

	#-----------------------------------------------------------------------------------------------------------
	# mean_spd = spd_array_can0.mean()
	# if mean_spd > config.threashold_spd:
	# 	spd_flag = 1
	# else:
	# 	spd_flag = 0

	combined_matrix = mat_can1
	spd_flag = 1

	return (combined_matrix, decode_time, spd_flag)


def speedDecode(obj_can0, act_num_can0):
	temp_list = []

	if act_num_can0 > 0:
		count = 0
		while count < act_num_can0:
			#print(obj_can0[count].ID)
			if (obj_can0[count].ID == 0x3d1):  # ID of speed channel
				spd = vehicle_db.decode_message(obj_can0[count].ID, obj_can0[count].Data)
				
				#print(spd)
				for k, v in spd.items():
					if k == 'VehSpdAvgDrvnHSC5':  # name of speed channel VehSpdAvgDrvnHSC1
						if v == 'km/h (0x0 - 0x7FFF)':
							temp_list.append(0)
						else:
							spd = float(v)
							temp_list.append(spd)
						break
			count = count + 1
	# print(temp_list)
	return temp_list



def brakeDecode(obj_can0, act_num_can0):
	temp_list = []

	if act_num_can0 > 0:
		count = 0
		while count < act_num_can0:
			#print(obj_can0[count].ID)
			if (obj_can0[count].ID == 0xf1):  # ID of speed channel
				brake = vehicle_db.decode_message(obj_can0[count].ID, obj_can0[count].Data)
				
				#print(brake)
				for k, v in brake.items():
				 	brake = float(v)
				 	temp_list.append(brake)
				 		
			count = count + 1
	# print(temp_list)
	return temp_list



