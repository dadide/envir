#Antzer calling SDK with Python example
#-------------------------------------import-------------------------------------=
import struct
import threading
import time
import numpy as np
from ctypes import *
from ctypes import cdll, c_uint, POINTER
from enum import IntEnum
from datetime import datetime

from scipy import signal
import config
import cantools
#-------------------------------Load dynamic lib-----------------------------------------
# zlg-------------------------------
canmini_so = cdll.LoadLibrary('lib/zlglibusbcan.so') #  can lib
sensor_decode_so = cdll.LoadLibrary('lib/zlgdecode.so')

# taiwan-------------------------------
clib = cdll.LoadLibrary('lib/libfaro_can_sdk.so')
sensor_decode_lib = cdll.LoadLibrary('lib/mveg2110_20210524.so')
sensor_decode_lib2 = cdll.LoadLibrary('lib/mveg2110_20210524_2.so')
vehicle_db = cantools.database.load_file('lib/EP22_brief_20210714_02.dbc')

#-------------------------------------Define-------------------------------------=
# zlg-------------------------------
dim_canmini=36		# channel number = column of mat
id_num_canmini=12	# sensor number

def p0End_zlg():
	canmini_so.VCI_ResetCAN(USBCAN2,DEVICE_INDEX,CHANNEL0)
	canmini_so.VCI_ResetCAN(USBCAN2,DEVICE_INDEX,CHANNEL1)
	canmini_so.VCI_CloseDevice(USBCAN2,DEVICE_INDEX,CHANNEL0)
	canmini_so.VCI_CloseDevice(USBCAN2,DEVICE_INDEX,CHANNEL1)

class DBC_INFO(Structure):
	_fields_ = [("matrix_column_value", c_int),
				("matrix_row", c_int),
				("frequency", c_int),
				("matrix_row_value", c_int),
				("timestamp",c_int),#int timestamp;
				("calcul_batch",c_int),
				('id_num_can',c_int)
				]


class ZCAN_CAN_INIT_CONFIG(Structure):
	_fields_ = [("AccCode",c_int),
				("AccMask",c_int),
				("Reserved",c_int),
				("Filter",c_ubyte),
				("Timing0",c_ubyte),
				("Timing1",c_ubyte),
				("Mode",c_ubyte)]

class ZCAN_CAN_OBJ(Structure):
	_fields_ = [("ID",c_uint32),
				("TimeStamp",c_uint32),
				("TimeFlag",c_uint8),
				("SendType",c_byte),
				("RemoteFlag",c_byte),
				("ExternFlag",c_byte),
				("DataLen",c_byte),
				("Data",c_ubyte*8),
				("Reserved",c_ubyte*3)]

def can_start_zlg(DEVCIE_TYPE,DEVICE_INDEX,CHANNEL,Brate):
	 init_config  = ZCAN_CAN_INIT_CONFIG()
	 init_config.AccCode	= 0
	 init_config.AccMask	= 0xFFFFFFFF
	 init_config.Reserved   = 0
	 init_config.Filter	 = 1
	 init_config.Timing0	= 0x00
	 init_config.Timing1	= Brate
	 init_config.Mode	   = 0
	 # Initialize the  Can channel 
	 Init_flag=canmini_so.VCI_InitCAN(DEVCIE_TYPE,DEVICE_INDEX,CHANNEL,byref(init_config))
	 if Init_flag ==0:
		 print("InitCAN fail!")
	 else:
		 print("InitCAN success!")
	  #Start  Can channel	
	 start_flag=canmini_so.VCI_StartCAN(DEVCIE_TYPE,DEVICE_INDEX,CHANNEL)
	 if start_flag ==0:
		 print("StartCAN fail!")
	 else:
		 print("StartCAN success!")
	 return start_flag

ZCAN_DEVICE_TYPE  = c_uint32
ZCAN_DEVICE_INDEX = c_uint32
ZCAN_Reserved	 = c_uint32
ZCAN_CHANNEL	  = c_uint32
LEN			   = c_uint32

USBCAN2	   =   ZCAN_DEVICE_TYPE(4)
DEVICE_INDEX  =   ZCAN_DEVICE_INDEX(0)
Reserved	  =   ZCAN_Reserved(0)

# specify which channel to receive data 0--> channel 0	  1--> channel 1
CHANNEL0	   =   ZCAN_CHANNEL(0) # for receiving acceleration 
CHANNEL1	   =   ZCAN_CHANNEL(1) # for receiving time and speed 

Brate0=0x1C # bode rate for channel 0 
Brate1=0x14 # bode rate for channel 1
# close can if they open unexpectally 
bRel0=canmini_so.VCI_CloseDevice(USBCAN2,DEVICE_INDEX, CHANNEL0) # close can 1
bRel1=canmini_so.VCI_CloseDevice(USBCAN2,DEVICE_INDEX, CHANNEL1)  # close can 2

# open device
open_flag=canmini_so.VCI_OpenDevice(USBCAN2,DEVICE_INDEX,Reserved) # open device 

if open_flag ==0:
 	print("Opendevice fail!")
else:
 		print("Opendevice success!")

# start can 
canstart0 = can_start_zlg(USBCAN2,DEVICE_INDEX,CHANNEL0,Brate0) # start can 0
canstart1 = can_start_zlg(USBCAN2,DEVICE_INDEX,CHANNEL1,Brate1) # start can 1



# taiwan-------------------------------

MAIN_VER = 1
MINOR_VER = 0

DWREAD_Type = c_uint32
CAN_BAUD_RATE_TYPE = c_int

#CAN Baud rate
CAN_SPEED_1M   = CAN_BAUD_RATE_TYPE(0)
CAN_SPEED_800K = CAN_BAUD_RATE_TYPE(1)
CAN_SPEED_500K = CAN_BAUD_RATE_TYPE(2)
CAN_SPEED_250K = CAN_BAUD_RATE_TYPE(3)
CAN_SPEED_200K = CAN_BAUD_RATE_TYPE(4)
CAN_SPEED_125K = CAN_BAUD_RATE_TYPE(5)

# port_name = bytes("/dev/ttyUSB0","gbk") # Device name
# CAN_PORT0_BR = CAN_SPEED_1M           # Set port0 baud rate
# CAN_PORT1_BR = CAN_SPEED_1M           # Set port1 baud rate

port_name = bytes("/dev/antzerCAN0","gbk") # Device name
CAN_PORT0_BR = CAN_SPEED_500K           # Set port0 baud rate
CAN_PORT1_BR = CAN_SPEED_500K           # Set port1 baud rate
#-------------------------------------Structure-------------------------------------=
# class DBC_INFO(Structure):
# 	_fields_ = [("matrix_column_value", c_int),
# 				("matrix_row", c_int),
# 				("frequency", c_int),
# 				("matrix_row_value", c_int),
# 				("timestamp",c_int),#int timestamp;
# 				("calcul_batch",c_int),
# 				('id_num_can',c_int)
# 				]

class can_fw_ver_t(Structure):
    _fields_ = [("main",c_ubyte),
                ("minor",c_ubyte),
                ("type",c_ubyte),
                ("year",c_ubyte),
                ("week",c_ubyte),
                ("sub1",c_ubyte),
				("sub2",c_ubyte),
                ("rc",c_ubyte)]

# port = 0 or 1
# speed = CAN_SPEED_1M to CAN_SPEED_125K
class can_config_t(Structure):
	_fields_ = [("port",c_ubyte),
		("speed",c_int)]

class can_message_t(Structure):
	_fields_ = [("port",c_ubyte),
				("id",c_uint32),
                ("mode",c_ubyte), #CAN 2.0A/B (STD/Extended)
                ("rtr",c_ubyte),  #Remote request
                ("dlc",c_ubyte),
                ("data",c_ubyte*8)]

#-------------------------------------Function-------------------------------------=			
def can_start_taiwan():
	can_fw_ver  = can_fw_ver_t()
	retVer = clib.AZ_VC_GetFWVer(byref(can_fw_ver)) #Show FARO/GAND FW version
	if retVer != 0:
		print("Calling AZ_VC_GetFWVer fail")
		exit(0)
	else:
		print(hex(can_fw_ver.main) + "," + hex(can_fw_ver.minor) + "," + hex(can_fw_ver.type) + "," + hex(can_fw_ver.year) + "," + hex(can_fw_ver.week))

	retPort0Mode = clib.AZ_VC_ModeActive(0x00,0x00)	#set port0 mode to RAW CAN mode
	if retPort0Mode != 0:
		print("ERROR: Failed to switch port0 mode")
		exit(0)

	retPort1Mode = clib.AZ_VC_ModeActive(0x01,0x00)	#set port1 mode to RAW CAN mode
	if retPort0Mode != 0:
		print("ERROR: Failed to switch port1 mode")
		exit(0)

	can_cfg = can_config_t()
	can_cfg.port = 0  #Port 0
	can_cfg.speed = CAN_PORT0_BR #500k bps
	retCanCfg = clib.AZ_VC_CAN_Config(can_cfg) #Set port0 baud rate
	if retCanCfg != 0:
		print("ERROR: Set baud rate of CAN port0 fail")
		exit(0)

	can_cfg.port = 1  #Port1
	can_cfg.speed = CAN_PORT1_BR #500k bps
	retCanCfg = clib.AZ_VC_CAN_Config(can_cfg) #Set port1 baud rate
	if retCanCfg != 0:
		print("ERROR: Set baud rate of CAN port1 fail")

def send_thread():  #Send CAN data thread
	try:
		send_can_data = can_message_t()
		send_can_data.port = 0
		send_can_data.id = 0x7E8
		send_can_data.mode = 0
		send_can_data.rtr = 0
		send_can_data.dlc = 8
		send_can_data.data[0] = 0x03
		send_can_data.data[1] = 0x41
		send_can_data.data[2] = 0x0D
		send_can_data.data[3] = 0x06
		send_can_data.data[4] = 0xAA
		send_can_data.data[5] = 0xAA
		send_can_data.data[6] = 0xAA
		send_can_data.data[7] = 0xAA
		for i in range(30):
			ret = clib.AZ_VC_CAN_Write(send_can_data)
			if ret != 0:
				break
			time.sleep(1) #sleep 1s
		print("Send End")
	finally:
		print("Send thread End")

def p0End_taiwan():
	ret=clib.AZ_VC_DeInit()
	if ret !=0:
		print("Closedevice Failed!")
	else:
		print("Closedevice success!")
	del clib
	print('done')

# -------------------start----------------------
print("V%d,%d"%(MAIN_VER, MINOR_VER)) #Show python code version
ret1 = clib.AZ_VC_Init(port_name,4) #921600 bps
# ret0 = clib.AZ_VC_Init(port_name,4) #921600 bps
if ret1 !=0:
	print("Opendevice fail!")
	exit(0)
else:
	print("Opendevice success!")

can_start_taiwan() #Init CAN
#receive initial
rec_can_data = can_message_t()
dwread = DWREAD_Type(0)
#send initial
# Create thread
sendT = threading.Thread(target = send_thread)
# Run thread
#		sendT.start() #Enable it for sending data.
print('Start sending/receiving data')

#-------------------------------------Main function-------------------------------------

# # ---------------------------------------can 1---------------------------------------
frequ = 512
calcul_batch = 5
obj_can1 = (ZCAN_CAN_OBJ * 100000)() # matrix_row_value)()
mat_can1 = np.zeros([frequ * calcul_batch, dim_canmini], np.float64) - 1
tmp_can1 = np.asarray(mat_can1)
dataptr_can1 = tmp_can1.ctypes.data_as(POINTER(c_double))

def receive_can_data(calcul_batch, frequ, nPre_channel, decode_time, dataptr_can1):
	s1_time = time.time()
	matrix_row_value = frequ * calcul_batch

	# ---------------------------------------can 0---------------------------------------
	TMSpd_h1HSC1_list = []
	EPTAccelActuPosHSC1_list = []
	BrkPdlPos_h1HSC1_list = []
	VehDynYawRateHSC1_list = []
	StrgWhlAngHSC1_list = []
	StrgWhlAngGrdHSC1_list = []
	VehSpdAvgDrvnHSC1_list = []
	VehSpdAvgNonDrvnHSC1_list = []
	WhlGndVelLDrvnHSC1_list = []
	WhlGndVelRDrvnHSC1_list = []
	ACAmbtTemHSC1_list = []
	ACEvapoTemHSC1_list = []
	EPTDrvrReqInptShaftToqHSC1_list = []
	EPTTrInptShaftToqHSC1_list = []
	EPTTrInptShaftSpdHSC1_list = []
	WhlGndVelLNonDrvnHSC1_list = []
	WhlGndVelRNonDrvnHSC1_list = []



	TMSpd_h1HSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	EPTAccelActuPosHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	BrkPdlPos_h1HSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	VehDynYawRateHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	StrgWhlAngHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	StrgWhlAngGrdHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	VehSpdAvgDrvnHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	VehSpdAvgNonDrvnHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	WhlGndVelLDrvnHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	WhlGndVelRDrvnHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	ACAmbtTemHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	ACEvapoTemHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	EPTDrvrReqInptShaftToqHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	EPTTrInptShaftToqHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	EPTTrInptShaftSpdHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	WhlGndVelLNonDrvnHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1
	WhlGndVelRNonDrvnHSC1_mat = np.zeros([frequ * calcul_batch, 1], np.float64) - 1


	# # ---------------------------------------can 1---------------------------------------
	dbc_info_can1 = DBC_INFO(dim_canmini, 0, frequ, matrix_row_value, 0, calcul_batch, id_num_canmini)

	# # ---------------------------------------can 1---------------------------------------

	init_time = time.time() - s1_time
	# print('init_time: ' + str(init_time))

	for time_index in range(0, calcul_batch):

		wait_time = 1 - decode_time - init_time
		print(wait_time)
		if wait_time <= 0:
			print('Oh! Wait more than 1 seconds!!! No need to wait!!!' + str(wait_time))
		else:
			time.sleep(wait_time)
		
		init_time = 0
		s2_time = time.time()
		# ---------------------------------------receive data from can zlg---------------------------------------

		max_num_can1 = canmini_so.VCI_GetReceiveNum(USBCAN2, DEVICE_INDEX, CHANNEL1)  # preview the number of data in cache
		act_num_can1 = canmini_so.VCI_Receive(USBCAN2, DEVICE_INDEX, CHANNEL1, byref(obj_can1), max_num_can1, 100)
		print(time_index, max_num_can1)
		if act_num_can1 > 0:
			try:
				t = sensor_decode_so.DBC_Decode(byref(obj_can1), act_num_can1, time_index, dataptr_can1, byref(dbc_info_can1))
				# print(t)
			except Exception as e:
				p0End_zlg();


		# ---------------------------------------debug-taiwan-------------------------------------

		# retRecCan = clib.AZ_VC_CAN_Read(byref(rec_can_data), byref(dwread))
		# if retRecCan == 0:
		# 	print("port:%x ,Timestamp:%s ,id:%x , dlc:%d ,data:%s"%(rec_can_data.port,str(datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]),rec_can_data.id,rec_can_data.dlc,''.join(hex(rec_can_data.data[j])+ ' 'for j in range(rec_can_data.dlc))))
		# else:
		# 	exit(0)

		# ---------------------------------------receive data from can taiwan---------------------------------------
		dataLeng = clib.AZ_VC_CAN_Read_Amount()
		print(time_index, dataLeng)


		for dl in range(dataLeng):  #The amount of can data received
			retRecCan = clib.AZ_VC_CAN_Read(byref(rec_can_data), byref(dwread))
			if retRecCan == 0:
				TMSpd_h1HSC1_list = deviceDecode(rec_can_data, TMSpd_h1HSC1_list, 0x94)
				EPTAccelActuPosHSC1_list = deviceDecode(rec_can_data, EPTAccelActuPosHSC1_list, 0xaf)
				BrkPdlPos_h1HSC1_list = deviceDecode(rec_can_data, BrkPdlPos_h1HSC1_list, 0xf1)
				VehDynYawRateHSC1_list = deviceDecode(rec_can_data, VehDynYawRateHSC1_list, 0x1e9)
				StrgWhlAngHSC1_list = deviceDecode2keys(rec_can_data, StrgWhlAngHSC1_list, 0x1e5, 'StrgWhlAngHSC1')
				StrgWhlAngGrdHSC1_list = deviceDecode2keys(rec_can_data, StrgWhlAngGrdHSC1_list, 0x1e5, 'StrgWhlAngGrdHSC1')
				VehSpdAvgDrvnHSC1_list = deviceDecode2keys(rec_can_data, VehSpdAvgDrvnHSC1_list, 0x353, 'VehSpdAvgDrvnHSC1')
				VehSpdAvgNonDrvnHSC1_list = deviceDecode2keys(rec_can_data, VehSpdAvgNonDrvnHSC1_list, 0x353, 'VehSpdAvgNonDrvnHSC1')
				WhlGndVelLDrvnHSC1_list = deviceDecode2keys(rec_can_data, WhlGndVelLDrvnHSC1_list, 0x348, 'WhlGndVelLDrvnHSC1')
				WhlGndVelRDrvnHSC1_list = deviceDecode2keys(rec_can_data, WhlGndVelRDrvnHSC1_list, 0x348, 'WhlGndVelRDrvnHSC1')
				ACAmbtTemHSC1_list = deviceDecode2keys(rec_can_data, ACAmbtTemHSC1_list, 0x379, 'ACAmbtTemHSC1')
				ACEvapoTemHSC1_list = deviceDecode2keys(rec_can_data, ACEvapoTemHSC1_list, 0x379, 'ACEvapoTemHSC1')
				EPTDrvrReqInptShaftToqHSC1_list = deviceDecode2keys(rec_can_data, EPTDrvrReqInptShaftToqHSC1_list, 0x19c, 'EPTDrvrReqInptShaftToqHSC1')
				EPTTrInptShaftToqHSC1_list = deviceDecode2keys(rec_can_data, EPTTrInptShaftToqHSC1_list, 0x19c, 'EPTTrInptShaftToqHSC1')
				EPTTrInptShaftSpdHSC1_list = deviceDecode2keys(rec_can_data, EPTTrInptShaftSpdHSC1_list, 0x19c, 'EPTTrInptShaftToqHSC1')
				WhlGndVelLNonDrvnHSC1_list = deviceDecode2keys(rec_can_data, WhlGndVelLNonDrvnHSC1_list, 0x34a, 'WhlGndVelLNonDrvnHSC1')
				WhlGndVelRNonDrvnHSC1_list = deviceDecode2keys(rec_can_data, WhlGndVelRNonDrvnHSC1_list, 0x34a, 'WhlGndVelRNonDrvnHSC1')
			else:
				exit(0)


		decode_time = time.time() - s2_time
		# print('decode_time: ' + str(decode_time))


# ---------------------------------------------------------------------------------------------------------------------
	s2_time = time.time()

	TMSpd_h1HSC1_array = np.asarray(TMSpd_h1HSC1_list)
	EPTAccelActuPosHSC1_array = np.asarray(EPTAccelActuPosHSC1_list)
	BrkPdlPos_h1HSC1_array = np.asarray(BrkPdlPos_h1HSC1_list)
	VehDynYawRateHSC1_array = np.asarray(VehDynYawRateHSC1_list)
	StrgWhlAngHSC1_array = np.asarray(StrgWhlAngHSC1_list)
	StrgWhlAngGrdHSC1_array = np.asarray(StrgWhlAngGrdHSC1_list)
	VehSpdAvgDrvnHSC1_array = np.asarray(VehSpdAvgDrvnHSC1_list)
	VehSpdAvgNonDrvnHSC1_array = np.asarray(VehSpdAvgNonDrvnHSC1_list)
	WhlGndVelLDrvnHSC1_array = np.asarray(WhlGndVelLDrvnHSC1_list)
	WhlGndVelRDrvnHSC1_array = np.asarray(WhlGndVelRDrvnHSC1_list)
	ACAmbtTemHSC1_array = np.asarray(ACAmbtTemHSC1_list)
	ACEvapoTemHSC1_array = np.asarray(ACEvapoTemHSC1_list)
	EPTDrvrReqInptShaftToqHSC1_array = np.asarray(EPTDrvrReqInptShaftToqHSC1_list)
	EPTTrInptShaftToqHSC1_array = np.asarray(EPTTrInptShaftToqHSC1_list)
	EPTTrInptShaftSpdHSC1_array = np.asarray(EPTTrInptShaftSpdHSC1_list)
	WhlGndVelLNonDrvnHSC1_array = np.asarray(WhlGndVelLNonDrvnHSC1_list)
	WhlGndVelRNonDrvnHSC1_array = np.asarray(WhlGndVelRNonDrvnHSC1_list)

	# up and down must be >= 1 if the shape is 0, 
	# print(    TMSpd_h1HSC1_array.shape[0])
	# print(	EPTAccelActuPosHSC1_array.shape[0])
	# print(	BrkPdlPos_h1HSC1_array.shape[0])
	# print(	VehDynYawRateHSC1_array.shape[0])
	# print(	StrgWhlAngHSC1_array.shape[0])
	# print(	StrgWhlAngGrdHSC1_array.shape[0])
	# print(	VehSpdAvgDrvnHSC1_array.shape[0])
	# print(	VehSpdAvgNonDrvnHSC1_array.shape[0])
	# print(	WhlGndVelLDrvnHSC1_array.shape[0])
	# print(	WhlGndVelRDrvnHSC1_array.shape[0])
	# print(	ACAmbtTemHSC1_array.shape[0])
	# print(	ACEvapoTemHSC1_array.shape[0])
	# print(	EPTDrvrReqInptShaftToqHSC1_array.shape[0])
	# print(	EPTTrInptShaftToqHSC1_array.shape[0])
	# print(	EPTTrInptShaftSpdHSC1_array.shape[0])
	# print(	WhlGndVelLNonDrvnHSC1_array.shape[0])
	# print(	WhlGndVelRNonDrvnHSC1_array.shape[0])
	try:
		TMSpd_h1HSC1_array = signal.resample_poly(TMSpd_h1HSC1_array, frequ * calcul_batch, TMSpd_h1HSC1_array.shape[0], padtype='line')
		EPTAccelActuPosHSC1_array = signal.resample_poly(EPTAccelActuPosHSC1_array, frequ * calcul_batch, EPTAccelActuPosHSC1_array.shape[0], padtype='line')
		BrkPdlPos_h1HSC1_array = signal.resample_poly(BrkPdlPos_h1HSC1_array, frequ * calcul_batch, BrkPdlPos_h1HSC1_array.shape[0], padtype='line')
		VehDynYawRateHSC1_array = signal.resample_poly(VehDynYawRateHSC1_array, frequ * calcul_batch, VehDynYawRateHSC1_array.shape[0], padtype='line')
		StrgWhlAngHSC1_array = signal.resample_poly(StrgWhlAngHSC1_array, frequ * calcul_batch, StrgWhlAngHSC1_array.shape[0], padtype='line')
		StrgWhlAngGrdHSC1_array = signal.resample_poly(StrgWhlAngGrdHSC1_array, frequ * calcul_batch, StrgWhlAngGrdHSC1_array.shape[0], padtype='line')
		VehSpdAvgDrvnHSC1_array = signal.resample_poly(VehSpdAvgDrvnHSC1_array, frequ * calcul_batch, VehSpdAvgDrvnHSC1_array.shape[0], padtype='line')
		VehSpdAvgNonDrvnHSC1_array = signal.resample_poly(VehSpdAvgNonDrvnHSC1_array, frequ * calcul_batch, VehSpdAvgNonDrvnHSC1_array.shape[0], padtype='line')
		WhlGndVelLDrvnHSC1_array = signal.resample_poly(WhlGndVelLDrvnHSC1_array, frequ * calcul_batch, WhlGndVelLDrvnHSC1_array.shape[0], padtype='line')
		WhlGndVelRDrvnHSC1_array = signal.resample_poly(WhlGndVelRDrvnHSC1_array, frequ * calcul_batch, WhlGndVelRDrvnHSC1_array.shape[0], padtype='line')
		ACAmbtTemHSC1_array = signal.resample_poly(ACAmbtTemHSC1_array, frequ * calcul_batch, ACAmbtTemHSC1_array.shape[0], padtype='line')
		ACEvapoTemHSC1_array = signal.resample_poly(ACEvapoTemHSC1_array, frequ * calcul_batch, ACEvapoTemHSC1_array.shape[0], padtype='line')
		EPTDrvrReqInptShaftToqHSC1_array = signal.resample_poly(EPTDrvrReqInptShaftToqHSC1_array, frequ * calcul_batch, EPTDrvrReqInptShaftToqHSC1_array.shape[0], padtype='line')
		EPTTrInptShaftToqHSC1_array = signal.resample_poly(EPTTrInptShaftToqHSC1_array, frequ * calcul_batch, EPTTrInptShaftToqHSC1_array.shape[0], padtype='line')
		EPTTrInptShaftSpdHSC1_array = signal.resample_poly(EPTTrInptShaftSpdHSC1_array, frequ * calcul_batch, EPTTrInptShaftSpdHSC1_array.shape[0], padtype='line')
		WhlGndVelLNonDrvnHSC1_array = signal.resample_poly(WhlGndVelLNonDrvnHSC1_array, frequ * calcul_batch, WhlGndVelLNonDrvnHSC1_array.shape[0], padtype='line')
		WhlGndVelRNonDrvnHSC1_array = signal.resample_poly(WhlGndVelRNonDrvnHSC1_array, frequ * calcul_batch, WhlGndVelRNonDrvnHSC1_array.shape[0], padtype='line')


		TMSpd_h1HSC1_mat = TMSpd_h1HSC1_array.reshape(TMSpd_h1HSC1_array.shape[0], 1)
		EPTAccelActuPosHSC1_mat = EPTAccelActuPosHSC1_array.reshape(EPTAccelActuPosHSC1_array.shape[0], 1)
		BrkPdlPos_h1HSC1_mat = BrkPdlPos_h1HSC1_array.reshape(BrkPdlPos_h1HSC1_array.shape[0], 1)
		VehDynYawRateHSC1_mat = VehDynYawRateHSC1_array.reshape(VehDynYawRateHSC1_array.shape[0], 1)
		StrgWhlAngHSC1_mat = StrgWhlAngHSC1_array.reshape(StrgWhlAngHSC1_array.shape[0], 1)
		StrgWhlAngGrdHSC1_mat = StrgWhlAngGrdHSC1_array.reshape(StrgWhlAngGrdHSC1_array.shape[0], 1)
		VehSpdAvgDrvnHSC1_mat = VehSpdAvgDrvnHSC1_array.reshape(VehSpdAvgDrvnHSC1_array.shape[0], 1)
		VehSpdAvgNonDrvnHSC1_mat = VehSpdAvgNonDrvnHSC1_array.reshape(VehSpdAvgNonDrvnHSC1_array.shape[0], 1)
		WhlGndVelLDrvnHSC1_mat = WhlGndVelLDrvnHSC1_array.reshape(WhlGndVelLDrvnHSC1_array.shape[0], 1)
		WhlGndVelRDrvnHSC1_mat = WhlGndVelRDrvnHSC1_array.reshape(WhlGndVelRDrvnHSC1_array.shape[0], 1)
		ACAmbtTemHSC1_mat = ACAmbtTemHSC1_array.reshape(ACAmbtTemHSC1_array.shape[0], 1)
		ACEvapoTemHSC1_mat = ACEvapoTemHSC1_array.reshape(ACEvapoTemHSC1_array.shape[0], 1)
		EPTDrvrReqInptShaftToqHSC1_mat = EPTDrvrReqInptShaftToqHSC1_array.reshape(EPTDrvrReqInptShaftToqHSC1_array.shape[0], 1)
		EPTTrInptShaftToqHSC1_mat = EPTTrInptShaftToqHSC1_array.reshape(EPTTrInptShaftToqHSC1_array.shape[0], 1)
		EPTTrInptShaftSpdHSC1_mat = EPTTrInptShaftSpdHSC1_array.reshape(EPTTrInptShaftSpdHSC1_array.shape[0], 1)
		WhlGndVelLNonDrvnHSC1_mat = WhlGndVelLNonDrvnHSC1_array.reshape(WhlGndVelLNonDrvnHSC1_array.shape[0], 1)
		WhlGndVelRNonDrvnHSC1_mat = WhlGndVelRNonDrvnHSC1_array.reshape(WhlGndVelRNonDrvnHSC1_array.shape[0], 1)
		
	except Exception as e:
		print('0 data from the vehicle CAN ')
		print(e)

# ---------------------------------------------------------------------------------------------------------------------
	# print(StrgWhlAngHSC1_mat.shape)
	# print(StrgWhlAngGrdHSC1_mat.shape)

	# -------8.20-----
	# del obj_can1
	# del mat_can1 
	# del tmp_can1

	combined_matrix_prechannel = np.hstack((TMSpd_h1HSC1_mat, EPTAccelActuPosHSC1_mat, BrkPdlPos_h1HSC1_mat,\
		VehDynYawRateHSC1_mat, StrgWhlAngHSC1_mat, StrgWhlAngGrdHSC1_mat, VehSpdAvgDrvnHSC1_mat, \
		VehSpdAvgNonDrvnHSC1_mat, WhlGndVelLDrvnHSC1_mat, WhlGndVelRDrvnHSC1_mat, \
		ACAmbtTemHSC1_mat, ACEvapoTemHSC1_mat, EPTDrvrReqInptShaftToqHSC1_mat, \
		EPTTrInptShaftToqHSC1_mat, EPTTrInptShaftSpdHSC1_mat,\
		WhlGndVelLNonDrvnHSC1_mat,  WhlGndVelRNonDrvnHSC1_mat))
	# print(combined_matrix_prechannel.shape)

	combined_matrix = np.hstack((combined_matrix_prechannel, mat_can1))
	# print(combined_matrix.shape)

	spd_flag = 1
	# add the hstack time & resample time to the decode_time
	decode_time = decode_time + time.time() - s2_time

	return combined_matrix, decode_time, spd_flag



def deviceDecode(obj_can0, temp_list, device_id):

	if (obj_can0.id == device_id):  # ID of speed channel
		message = vehicle_db.decode_message(obj_can0.id, obj_can0.data)
		
		#print(message)
		for k, v in message.items():
		 	message = float(v)
		 	temp_list.append(message)
				 		
	return temp_list

def deviceDecode2keys(obj_can0, temp_list, device_id, key):

	if (obj_can0.id == device_id):  # ID of speed channel
		message = vehicle_db.decode_message(obj_can0.id, obj_can0.data)
		
		#print(message)
		for k, v in message.items():
			if k == key:
			 	message = float(v)
			 	temp_list.append(message)
	return temp_list

