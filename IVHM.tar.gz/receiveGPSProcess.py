import serial  # 引用pySerial模組
import numpy as np
from scipy import signal
from scipy.interpolate import interp1d
import time

                  
BAUD_RATES = 115200    	                    # 設定傳輸速率
SampleRate = 5 #GPS模块的刷新率

COM_PORT1 = '/dev/ttyUSB1' 
COM_PORT3 = '/dev/ttyUSB3' 
try:
    ser = serial.Serial(COM_PORT1, BAUD_RATES)   # 初始化序列通訊埠
except:
    ser = serial.Serial(COM_PORT3, BAUD_RATES)   # 初始化序列通訊埠


def receviceGPS(p, last_gps):
    cnt = 0
    step_time = p.step_time
    gps_mat = np.zeros([step_time*SampleRate, 4]) - 1
    try:
        while True:
            while ser.in_waiting:          # 若收到序列資料…
                # print('ser.in_waiting: ' + str(ser.in_waiting))
                data_raw = ser.readline()  # 讀取一行
                try: 
                    data = data_raw.decode()   # 用預設的UTF-8解碼
                    # print('接收到的原始資料：', data_raw)  
                    # print('接收到的資料：', data)
                    line = data.strip()
                    element = line.split(',')
                    if element[0] == '$GPRMC':
                        # print('接收到的資料：', data)
                        # print(element[0], cnt)                    
                        if element[2] == 'A':
                            # new = [element[1], element[3], element[5], element[7]]
                            lat = float(element[3][:2]) + float(element[3][2:])/60
                            lon = float(element[5][:3]) + float(element[5][3:])/60
                            spd = float(element[7])*1.852
                            gps_data = [[ element[1], lat, lon, spd]]
                        elif element[2] == 'V':
                            if cnt != 0:    
                                gps_data = gps_mat[cnt-1, :]
                            else:   
                                gps_data = last_gps
                        gps_mat[cnt, :] = np.asarray(gps_data)
                        # print(cnt)     
                        cnt = cnt + 1
                        element[0] = 'kkk'
                        # print(element[0])
                except Exception as e:
                    print(e)
                    print('Abort the data, next line!')
                if cnt > step_time*SampleRate-1:
                    # print('break0000')
                    break
            if cnt > step_time*SampleRate-1:
                # print('break1111')
                break
        # print('finish gps rece')
        # print(gps_mat)
        return gps_mat
    except KeyboardInterrupt:
        ser.close()    # 清除序列通訊物件
        print('再見！') 


def reshapeGPS(gps_mat, p, SampleRate):
    # TODO: 师兄在这里写下reshape的代码即可
    # no 1 useless
    # 输入gps_mat是一个(5, 4)或者(10, 4)的numpy，输出也为一个(512*5, 4)的numpy

    upper_frequency = p.freque * p.step_time # changed 

    gps_time =gps_mat[:,0]
    gps_lat = gps_mat[:,1]
    gps_lon = gps_mat[:,2]
    gps_spd = gps_mat[:,3]
    
    x = np.linspace(1, p.step_time*SampleRate, num = p.step_time*SampleRate, endpoint=True) # changed
   
    f_time = interp1d(x, gps_time, kind="cubic")
    f_lat = interp1d(x, gps_lat, kind="cubic")
    f_lon = interp1d(x, gps_lon, kind="cubic")
    f_spd = interp1d(x, gps_spd, kind="cubic")
   
    xnew = np.linspace(1, p.step_time*SampleRate, num = upper_frequency, endpoint=True) # changed d

    gps_time_new = f_time(xnew)
    gps_lat_new = f_lat(xnew)
    gps_lon_new = f_lon(xnew)
    gps_spd_new = f_spd(xnew)

    gps_time_new = gps_time_new.reshape((len(gps_time_new), 1))
    gps_lat_new = gps_lat_new.reshape((len(gps_lat_new), 1))
    gps_lon_new = gps_lon_new.reshape((len(gps_lon_new), 1))
    gps_spd_new = gps_spd_new.reshape((len(gps_spd_new), 1))

    upper_gps_mat = np.hstack((gps_time_new, gps_lat_new, gps_lon_new , gps_spd_new))
    return upper_gps_mat


def addZero512(raw_gps_mat, p, SampleRate):

    upper_frequency = p.freque * p.step_time # changed 

    zero_mat = np.zeros((upper_frequency - raw_gps_mat.shape[0], raw_gps_mat.shape[1])) + 2

    upper_raw_gps_mat = np.vstack((raw_gps_mat, zero_mat))

    # print(raw_gps_mat.shape, zero_mat.shape, upper_raw_gps_mat.shape)

    return upper_raw_gps_mat

